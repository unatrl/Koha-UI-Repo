package C4::Labels;

use Modern::Perl;

BEGIN {

    use C4::Labels::Batch;
    use C4::Labels::Label;
    use C4::Labels::Layout;
    use C4::Labels::Profile;
    use C4::Labels::Template;
}

1;

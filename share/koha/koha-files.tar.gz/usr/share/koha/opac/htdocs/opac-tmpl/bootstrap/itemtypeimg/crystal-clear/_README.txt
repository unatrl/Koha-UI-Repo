The Crystal Clear icon set was created by
Everaldo Coelho, http://www.everaldo.com/
Submitted:  Oct 11 2003
Updated:  Jun 16 2007

Icons were acquired from Wikimedia Commons,
http://commons.wikimedia.org/wiki/Crystal_Clear, 30 Jan 2010.

The images were renamed, organized and re-sized to create this packager in a
standard icon package format.  This was preformed by Jeff Israel at the Open
Icon Library.

This package was created by the Open Icon Library,
http://openiconlibrary.sourceforge.net/ and is available for download there.T
All Icons are free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public License as published by the Free Software Foundation; either version 2.1 of the License, or (at your option) any later version. This library is distributed in the hope that it will be useful, but without any warranty; without even the implied warranty of merchantability or fitness for a particular purpose.

See COPYING.txt or http://www.everaldo.com/crystal/?action=license for details.

---------------

Added to this set were three images by RayAna Min Park (August 2011):

books-closed.png
books-open-cd.png
books-open.png

All Icons are free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public License as published by the Free Software Foundation; either version 2.1 of the License, or (at your option) any later version.